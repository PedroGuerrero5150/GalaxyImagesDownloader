package com.example.proyecto6;

import android.graphics.Bitmap;

import java.util.*;

public class Data{
    private LinkedHashMap<String, Photo> data;
    private LinkedHashMap<String,String> history;
    private Map<String, Bitmap> bitmaps;//cache

    //constructor privado
    private Data() {
        data = new LinkedHashMap<>();
        history = new LinkedHashMap();
        bitmaps = new HashMap<>();
    }

    //instancia unica privada
    private static Data ourInstance = new Data();

    //metodo regresar unica instanica
    public static Data getInstance() {
        return ourInstance;
    }

    //metodo borrar datos
    public void clear() {
        history.clear();
        data.clear();
        bitmaps.clear();
    }

    //getters, setters
    public LinkedHashMap<String,String> getHistory() {
        return history;
    }

    public LinkedHashMap<String,Photo> getData() {
        return data;
    }

    public void addHistory(String PhotoName) {
        int timesPresented = data.get(PhotoName).getTimesPresented() +1 ;
        data.get(PhotoName).setTimesPresented(timesPresented);
        history.put(PhotoName, "-Nombre Fotografia: " + PhotoName + "\n" +
                "Veces que se ha presentado: " + timesPresented + "\n\n");

    }

    public void addData(String photoName, String photoAddress, String photoDimensions){
        data.put(photoName, new Photo (photoName, photoAddress, photoDimensions));
    }

    public Map<String, Bitmap> getBitmaps() {
        return bitmaps;
    }
}

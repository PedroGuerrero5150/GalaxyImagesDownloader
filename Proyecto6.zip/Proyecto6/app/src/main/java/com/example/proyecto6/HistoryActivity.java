package com.example.proyecto6;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Collection;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    private TextView historyTextView;
    private Button clearDataButton;
    private static Data mData = Data.getInstance();;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        Context context = this;

        //binding elementos gui
        historyTextView = findViewById(R.id.historyTextView);
        clearDataButton = findViewById(R.id.clearDataButton);
        //mData = Data.getInstance();


        Handler handler = new Handler();

        handler.postDelayed(new Runnable() {
            public void run() {
                // Get the stack of Activity lifecycle methods called and print to TextView
                StringBuilder sbHistory = new StringBuilder();
                Collection <String> listHistory = mData.getHistory().values();
                for (String h : listHistory) {
                    sbHistory.insert(0, h + "\r\n");
                }
                if(historyTextView != null) {
                    historyTextView.setText(sbHistory.toString());
                }
            }
        }, 500);

        /*clearDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mData.clear();
            }

            //Intent intent = new Intent(context , HistoryActivity.class);
            //startActivity(intent);

        });*/


    }
}

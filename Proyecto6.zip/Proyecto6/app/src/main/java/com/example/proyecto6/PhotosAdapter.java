package com.example.proyecto6;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.*;

public class PhotosAdapter extends RecyclerView.Adapter<PhotosAdapter.ViewHolder>  {

    // listeners from MainActivity that are registered for each list item
    private final View.OnClickListener clickListener;
    private static Data mData;

    //constructor
    public PhotosAdapter(View.OnClickListener clickListener){
        this.clickListener = clickListener;
        this.mData = Data.getInstance();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public static TextView nameTextView;
        public static TextView addressTextView;
        public static TextView dimensionsTextView;

        // configures a RecyclerView item's ViewHolder
        public ViewHolder(View itemView,
                          View.OnClickListener clickListener) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            addressTextView = itemView.findViewById(R.id.addressTextView);
            dimensionsTextView = itemView.findViewById(R.id.dimensionsTextView);

            // attach listeners to itemView
            itemView.setOnClickListener(clickListener);
        }
    }

    @NonNull
    @Override
    public PhotosAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // inflate the list_item layout
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.list_items, parent, false);

        // create a ViewHolder for current item
        return (new ViewHolder(view, clickListener));
    }

    @Override
    public void onBindViewHolder(@NonNull PhotosAdapter.ViewHolder holder, int position) {

        /*//child views in gridLayout
        TextView nameTextView = findViewById(R.id.nameTextView);
        TextView addressTextView = holder.findViewById(R.id.addressTextView);
        TextView dimensionsTextView = holder.cell.findViewById(R.id.dimensionsTextView);*/

        //parse map values to arraylist
        Collection<Photo> values = mData.getData().values();
        ArrayList<Photo> listOfValues = new ArrayList<>(values);
        Photo p = listOfValues.get(position);


        //set children texts
        holder.nameTextView.setText(p.getName());
        holder.addressTextView.setText("Direccion: " + p.getURL());
        holder.dimensionsTextView.setText("Dimensiones: " + p.getDimensions());
        /**/
    }

    @Override
    public int getItemCount() {
        return mData.getData().size();
    }


    public Data getData() {return mData;}
}
